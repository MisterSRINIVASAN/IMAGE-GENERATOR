from django.shortcuts import render, redirect
from . models import *
from django.contrib import messages
import datetime
from django.db.models import Q
from django.db import connection
import random 
from django.db.models import Sum, Count
from django.conf import settings
from django.core.mail import send_mail
from django.core.mail import EmailMessage
from django.utils import timezone
from .render import Render
from django.template.loader import get_template
from django.http import HttpResponse
def hr_login(request):
	if request.session.has_key('hr'):
		return redirect("hr_dashboard")
	else:
		if request.method == 'POST':
			username = request.POST.get('uname')
			password =  request.POST.get('psw')
			post = HRTeam.objects.filter(username=username,password=password)
			if post:
				username = request.POST.get('uname')
				request.session['hr'] = username
				a = request.session['hr']
				sess = HRTeam.objects.only('id').get(username=a).id
				request.session['hr_id']=sess
				return redirect("hr_dashboard")
			else:
				messages.success(request, 'Invalid Username or Password')
	return render(request,'hr_login.html',{})
def hr_dashboard(request):
	if request.session.has_key('hr'):
		return render(request,'hr_dashboard.html',{})
	else:
		return render(request,'hr_login.html',{})
def logout(request):
    try:
        del request.session['hr']
    except:
     pass
    return render(request, 'hr_login.html', {})
def add_employee(request):
	if request.method == 'POST':
		employee_name = request.POST.get('employee_name')
		username = request.POST.get('username')
		password = request.POST.get('password')
		email = request.POST.get('email')
		mobile = request.POST.get('mobile')
		dob = request.POST.get('dob')
		doj = request.POST.get('doj')
		department = request.POST.get('department')
		user_type = request.POST.get('user_type')
		city = request.POST.get('city')
		bio_data = request.FILES['bio_data']
		address = request.POST.get('address')
		crt = Employee_Detail.objects.create(employee_name=employee_name,username=username,
		password=password,email=email,mobile=mobile,dob=dob,
		doj=doj,department=department,user_type=user_type,bio_data=bio_data,city=city,
		address=address)
		if crt:
			messages.success(request,'Employee Added Successfully')
	return render(request,'add_employee.html',{})
def employee(request):
	if request.session.has_key('hr'):
		detail = Employee_Detail.objects.all()
		return render(request,'employee.html',{'detail':detail})
	else:
		return render(request,'hr_login.html',{})
def edit_employee(request,pk):
	detail = Employee_Detail.objects.filter(id=pk)
	if request.method == 'POST':
		employee_name = request.POST.get('employee_name')
		username = request.POST.get('username')
		email = request.POST.get('email')
		mobile = request.POST.get('mobile')
		department = request.POST.get('department')
		user_type = request.POST.get('user_type')
		city = request.POST.get('city')
		address = request.POST.get('address')
		crt = Employee_Detail.objects.filter(id=pk).update(employee_name=employee_name,username=username,email=email,mobile=mobile,department=department,user_type=user_type,city=city,
		address=address)
		if crt:
			messages.success(request,'Employee Updated Successfully')
	return render(request,'edit_employee.html',{'detail':detail})
def delete(request,pk):
	if request.session.has_key('hr'):
		detail = Employee_Detail.objects.filter(id=pk).delete()
		return redirect('employee')
	else:
		return render(request,'hr_login.html',{})
def work_details(request,pk):
	if request.session.has_key('hr'):
		detail = Work_Detail.objects.filter(id=pk)
		return render(request,'work_details.html',{'detail':detail})
	else:
		return render(request,'hr_login.html',{})
def buyer_detail(request):
	if request.session.has_key('hr'):
		detail = Order_Detail.objects.all()
		return render(request,'buyer_detail.html',{'detail':detail})
	else:
		return render(request,'hr_login.html',{})
def employee_login(request):
	if request.session.has_key('employee'):
		return redirect("employee_dashboard")
	else:
		if request.method == 'POST':
			username = request.POST.get('uname')
			password =  request.POST.get('psw')
			user_type = request.POST.get('department')
			post = Employee_Detail.objects.filter(username=username,password=password,department=user_type,user_type='Manager')
			if post:
				username = request.POST.get('uname')
				request.session['employee'] = username
				request.session['department'] = user_type
				a = request.session['employee']
				sess = Employee_Detail.objects.only('id').get(username=a).id
				request.session['employee_id']=sess
				return redirect("employee_dashboard")
			else:
				messages.success(request, 'Invalid Username or Password')
	return render(request,'employee_login.html',{})
def employee_dashboard(request):
	if request.session.has_key('employee'):
		return render(request,'employee_dashboard.html',{})
	else:
		return render(request,'employee_login.html',{})
def employee_logout(request):
    try:
        del request.session['employee']
    except:
     pass
    return render(request, 'employee_login.html', {})
def employee_work(request):
	if request.session.has_key('employee'):
		dept = request.session['department']
		detail = Work_Detail.objects.filter(department=dept)
		return render(request,'employee_work.html',{'detail':detail})
	else:
		return render(request,'employee_login.html',{})
def edit(request,pk):
	if request.session.has_key('employee'):
		dept = request.session['department']
		detail = Work_Detail.objects.filter(department=dept,id=pk)
		if request.method == 'POST':
			final_delivered_Quantity = request.POST.get('final_delivered_Quantity')
			status = request.POST.get('status')
			crt = Work_Detail.objects.filter(department=dept,id=pk).update(final_delivered_Quantity=final_delivered_Quantity,status=status)
			if crt:
				return redirect('employee_work')
		return render(request,'edit.html',{'detail':detail})
	else:
		return render(request,'employee_login.html',{})
def employee_attendance(request):
    if request.session.has_key('hr'):
        return render(request,'employee_attendance.html',{})
    else:
        return redirect("hr_login")
def show_attendance(request):
    if request.session.has_key('hr'):
        date = request.GET.get('date')
        detail = Employee_Detail.objects.all()
        if request.method == 'POST':
            student_id = request.POST.getlist('emp_id[]')
            attendance = request.POST.getlist('attendance[]')
            date = request.POST.get('date')
            month = request.POST.get('month')
            length=len(student_id)
            for row in range(0,length):
                s_id =  Employee_Detail.objects.get(id=int(student_id[row]))
                ad = Attendance.objects.create(employee_id=s_id,month=month,
                date=date,attendance=attendance[row])
                if ad:
                    messages.success(request,'Added')
        att = Attendance.objects.filter(date=date)
        tot = Attendance.objects.filter(date=date).aggregate(Count('employee_id'))
        present = Attendance.objects.filter(date=date,attendance='yes').aggregate(Count('attendance'))
        absent = Attendance.objects.filter(date=date,attendance='no').aggregate(Count('attendance'))
        return render(request,'show_attendance.html',{'detail':detail,'att':att,'tot':tot,'present':present,'absent':absent})
    else:
        return redirect("hr_login")
from django.contrib.auth.decorators import login_required
@login_required
def rise_invoice(request):
	detail = Order_Detail.objects.filter(invoice_status='NotSend')
	return render(request,'rise_invoice.html',{'detail':detail})
def gen_pdf(request):
    ids = request.GET.get('order_id')
    order_ids = request.GET.get('id')
    sales = Order_Detail.objects.filter(order_id=ids,id=int(order_ids))
    invoice = Invoice.objects.filter(order_id=ids,buyer_name=int(order_ids))
    today = timezone.now()
    params = {
        'today': today,
        'sales': sales,
        'request': request,
        'invoice':invoice
    }
    return Render.render('pdf.html', params)
@login_required
def invoice(request,pk):
	detail = Order_Detail.objects.filter(id=pk)
	ids = Order_Detail.objects.get(id=pk)
	if request.method == 'POST':
		order_id = request.POST.get('order_id')
		amount = request.POST.get('amount')
		due_date = request.POST.get('due_date')
		notes = request.POST.get('notes')
		Order_Detail.objects.filter(id=pk,order_id=order_id).update(invoice_status='Rised')
		crt = Invoice.objects.create(order_id=order_id,amount=amount,due_date=due_date,
		notes=notes,payment_status='rised',buyer_name=ids)
		if crt:
			return redirect('rised_invoice')
	return render(request,'invoice.html',{'detail':detail})
@login_required
def rised_invoice(request):
	detail = Invoice.objects.filter(payment_status='rised')
	return render(request,'rised_invoice.html',{'detail':detail})
def email(request):
    if request.method == "POST":
        form = EmailForm(request.POST,request.FILES)
        if form.is_valid():
            cid = request.GET.get('cid')
            post = form.save(commit=False)
            post.published_date = timezone.now()
            post.clientname = int(cid)
            post.projectid = int(request.GET.get('pid'))
            post.invoiceid = int(request.GET.get('iid'))
            post.status ='send'
            post.save()
            email = request.POST.get('email')
            subject = request.POST.get('subject')
            message = request.POST.get('message')
            document = request.FILES.get('document')
            email_from = settings.EMAIL_HOST_USER
            recipient_list = [email]
            bcc_email = settings.EMAIL_HOST_USER
            email = EmailMessage(subject,message,email_from,recipient_list,bcc=[bcc_email])
            base_dir = 'media/documents/'
            email.attach_file('media/documents/'+str(document))
            email.send()
            invoiceid = request.GET.get('iid')
            date = datetime.now()
            Invoice.objects.filter(pk=int(invoiceid)).update(status='send',mail_send_date=date)
            return redirect('payment_pending')
    else:
        form = EmailForm()
    return render(request, 'billing/email_form.html', {'form': form})