from django.contrib import admin
from .models import *
class StockInline(admin.TabularInline):
    model = Stock_Detail
    extra = 1
class PersonAdmin(admin.ModelAdmin):
    inlines = (StockInline,)

class StockAdmin(admin.ModelAdmin):
    inlines = (StockInline,)
admin.site.register(Order_Detail)
admin.site.register(HRTeam)
admin.site.register(Stock, StockAdmin)
admin.site.register(Employee_Detail)
admin.site.register(Work_Detail)
admin.site.register(Shipping)
admin.site.register(Attendance)
admin.site.register(Invoice)