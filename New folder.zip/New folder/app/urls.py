from django.urls import path
from . import views

urlpatterns = [
	path('', views.rise_invoice,name="rise_invoice"),
	path('hr_login/', views.hr_login,name="hr_login"),
	path('hr_dashboard/', views.hr_dashboard,name="hr_dashboard"),
	path('logout/', views.logout,name="logout"),
	path('add_employee/', views.add_employee,name="add_employee"),
	path('employee/', views.employee,name="employee"),
	path('edit_employee/<int:pk>/', views.edit_employee,name="edit_employee"),
	path('delete/<int:pk>/', views.delete,name="delete"),
	path('work_details/<int:pk>/', views.work_details,name="work_details"),
	path('buyer_detail/', views.buyer_detail,name="buyer_detail"),
	path('employee_login/', views.employee_login,name="employee_login"),
	path('employee_dashboard/', views.employee_dashboard,name="employee_dashboard"),
	path('employee_logout/', views.employee_logout,name="employee_logout"),
	path('employee_work/', views.employee_work,name="employee_work"),
	path('edit/<int:pk>/', views.edit,name="edit"),
	path('employee_attendance/', views.employee_attendance,name="employee_attendance"),
	path('show_attendance/', views.show_attendance,name="show_attendance"),
	path('render/pdf/', views.gen_pdf,name='gen_pdf'),
	path('invoice/<int:pk>/', views.invoice,name='invoice'),
	path('rised_invoice/', views.rised_invoice,name="rised_invoice"),
	
]
